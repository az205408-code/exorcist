using Mirror;
using UnityEngine;

public class NetworkManagerExorcist : NetworkManager
{
    public string gameplayScene = "HauntedHouse";
    public string lobbyScene = "Lobby";
    public int maxPlayers = 5;

    public override void OnServerAddPlayer(NetworkConnectionToClient conn)
    {
        Transform start = GetStartPosition();
        GameObject player = Instantiate(playerPrefab, start ? start.position : Vector3.zero, start ? start.rotation : Quaternion.identity);
        NetworkServer.AddPlayerForConnection(conn, player);

        if (numPlayers >= maxPlayers)
        {
            ServerChangeScene(gameplayScene);
        }
    }

    public override void OnServerSceneChanged(string sceneName)
    {
        if (sceneName == gameplayScene)
        {
            int i = 0;
            foreach (var kv in Mirror.NetworkServer.connections)
            {
                var pc = kv.Value.identity.GetComponent<PlayerController>();
                pc.RpcAssignRole(i == 0 ? PlayerRole.Monster : PlayerRole.Survivor);
                i++;
            }
        }
    }
}
