using Mirror;
using UnityEngine;

public class HealingAndRevive : NetworkBehaviour
{
    [SyncVar] public int health = 100;
    [SyncVar] public bool isDowned = false;

    [Command]
    public void CmdDamage(int amount)
    {
        if (isDowned) return;
        health -= amount;
        if (health <= 0) { health = 0; isDowned = true; }
    }

    [Command]
    public void CmdHeal(int amount)
    {
        if (isDowned) return;
        health = Mathf.Min(100, health + amount);
    }

    [Command]
    public void CmdRevive(bool bySara)
    {
        if (!isDowned) return;
        isDowned = false;
        health = bySara ? 100 : 30;
    }
}
