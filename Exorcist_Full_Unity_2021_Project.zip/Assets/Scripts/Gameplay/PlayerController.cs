using Mirror;
using UnityEngine;

public enum PlayerRole { Survivor, Monster }

public class PlayerController : NetworkBehaviour
{
    [SyncVar] public PlayerRole role = PlayerRole.Survivor;
    public float moveSpeed = 3.5f;
    public Camera fpsCam;

    [ClientRpc]
    public void RpcAssignRole(PlayerRole r)
    {
        role = r;
        Debug.Log("Assigned role: " + r);
    }

    void Start()
    {
        if (isLocalPlayer)
        {
            if (fpsCam == null)
            {
                var camGO = new GameObject("FPSCam");
                fpsCam = camGO.AddComponent<Camera>();
                camGO.transform.SetParent(transform);
                camGO.transform.localPosition = new Vector3(0, 1.6f, 0);
                camGO.transform.localRotation = Quaternion.identity;
            }
        }
    }

    void Update()
    {
        if (!isLocalPlayer) return;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 dir = new Vector3(h, 0, v);
        transform.Translate(dir * moveSpeed * Time.deltaTime, Space.Self);

        if (role == PlayerRole.Monster && Input.GetMouseButtonDown(0))
        {
            CmdMonsterAttack();
        }
    }

    [Command]
    void CmdMonsterAttack()
    {
        Debug.Log("Monster attacked");
    }
}
