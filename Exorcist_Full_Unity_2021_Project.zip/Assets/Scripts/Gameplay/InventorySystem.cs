using Mirror;
using UnityEngine;
using System.Collections.Generic;

public class InventorySystem : NetworkBehaviour
{
    [SyncVar] public int maxSlots = 5;
    public SyncList<string> items = new SyncList<string>();

    [Command]
    public void CmdAddItem(string id)
    {
        if (items.Count < maxSlots) items.Add(id);
    }

    [Command]
    public void CmdUseItem(int index)
    {
        if (index >= 0 && index < items.Count) items.RemoveAt(index);
    }
}
