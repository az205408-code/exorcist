using Mirror;
using UnityEngine;

public class FlashlightSystem : NetworkBehaviour
{
    public Light lightComp;
    public float battery = 100f;
    public float drainPerSecond = 6f;

    void Start()
    {
        if (isLocalPlayer)
        {
            if (lightComp == null)
            {
                var l = new GameObject("Flashlight");
                l.transform.SetParent(transform);
                l.transform.localPosition = new Vector3(0, 1.7f, 0.2f);
                lightComp = l.AddComponent<Light>();
                lightComp.type = LightType.Spot;
                lightComp.range = 12f;
                lightComp.spotAngle = 45f;
                lightComp.enabled = false;
            }
        }
    }

    void Update()
    {
        if (!isLocalPlayer || lightComp == null) return;
        if (Input.GetKeyDown(KeyCode.F))
            lightComp.enabled = !lightComp.enabled;

        if (lightComp.enabled)
        {
            battery -= drainPerSecond * Time.deltaTime;
            if (battery <= 0f) { battery = 0f; lightComp.enabled = false; }
        }
    }
}
