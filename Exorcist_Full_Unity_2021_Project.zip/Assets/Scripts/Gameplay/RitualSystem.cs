using Mirror;
using UnityEngine;

public class RitualSystem : NetworkBehaviour
{
    [SyncVar] public bool allMainItemsPlaced = false;
    [SyncVar] public bool banishInProgress = false;
    [SyncVar] public float banishTimeHassan = 12f;
    [SyncVar] public float banishTimeOthers = 20f;

    [Command]
    public void CmdStartRitual(bool isHassanOnline)
    {
        if (!allMainItemsPlaced || banishInProgress) return;
        banishInProgress = true;
        float t = isHassanOnline ? banishTimeHassan : banishTimeOthers;
        Invoke(nameof(ServerCompleteBanish), t);
        RpcOnBanishStarted(t);
    }

    [Server]
    void ServerCompleteBanish()
    {
        RpcOnBanishCompleted();
    }

    [ClientRpc] void RpcOnBanishStarted(float t) { Debug.Log($"Banish started for {t} seconds"); }
    [ClientRpc] void RpcOnBanishCompleted() { Debug.Log("Banish completed! Monster defeated."); }
}
