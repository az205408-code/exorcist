using Mirror;
using UnityEngine;

public class HideInCloset : NetworkBehaviour
{
    [SyncVar] public bool isHidden = false;

    [Command]
    public void CmdToggleHide()
    {
        isHidden = !isHidden;
        RpcSyncHide(isHidden);
    }

    [ClientRpc]
    void RpcSyncHide(bool h)
    {
        var r = GetComponent<Renderer>();
        if (r) r.enabled = !h;
    }
}
