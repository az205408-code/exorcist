using UnityEngine;

public class LoginManager : MonoBehaviour
{
    public bool ValidateEmail(string email) => email.Contains("@") && email.EndsWith(".com");
    public bool ValidatePassword(string pass) => pass != null && pass.Length >= 8;
}
