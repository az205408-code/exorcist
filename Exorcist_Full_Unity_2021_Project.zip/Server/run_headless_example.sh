#!/usr/bin/env bash
./ExorcistServer -batchmode -nographics -quit
