# Exorcist (Unity 2021.3 LTS)
Multiplayer 4v1 horror (Mirror).

## How to open
- Open in Unity 2021.3 LTS.
- Packages/manifest.json already references Mirror via OpenUPM.

## Build Android via Cloud Build
1) Push this folder to a GitHub repo.
2) Unity Dashboard → Cloud Build → Connect repo → Target Android (IL2CPP, ARMv7+ARM64).
3) Build and download APK on your phone.

## Scenes
- Assets/Scenes/MainMenu.unity
- Assets/Scenes/Lobby.unity
- Assets/Scenes/HauntedHouse.unity
